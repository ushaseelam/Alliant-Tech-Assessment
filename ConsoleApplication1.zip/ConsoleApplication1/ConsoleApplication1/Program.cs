﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            ITerminal termial = new Terminal();
            termial.Scan("ABCDABAA");
            Console.WriteLine("Price is $" + termial.Total());

            termial.Scan("CCCCCCC");
            Console.WriteLine("Price is $" + termial.Total());

            termial.Scan("ABCD");
            Console.WriteLine("Price is $" + termial.Total());

            Console.ReadLine();
        }
    }
}
