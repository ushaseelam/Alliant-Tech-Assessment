﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public class Terminal : ITerminal
    {
        private double TotalPrice = 0;
        public void Scan(string item)
        {
            this.TotalPrice = 0;
                     
            Dictionary<char, int> dict = new Dictionary<char, int>();

            foreach(Char c in item)
            {
                if (dict.ContainsKey(c))
                    dict[c]++;
                else
                    dict.Add(c, 1);
            }
            

            foreach(var v in dict)
            {
                if(v.Key=='A')
                {
                    int total = v.Value;
                    while (total >= 4)
                    {
                        this.TotalPrice = this.TotalPrice + 7;
                        total = total - 4;
                    }
                    if (total > 0)
                        this.TotalPrice = this.TotalPrice+ total * 2;
                }
                else if(v.Key=='C')
                {
                    int total = v.Value;
                    while (total >= 6)
                    {
                        this.TotalPrice = this.TotalPrice + 6;
                        total = total - 6;
                    }
                    if (total > 0)
                        this.TotalPrice = this.TotalPrice+ total * 1.25;
                }
                if(v.Key=='B')
                {
                    if (v.Value > 0)
                        this.TotalPrice = this.TotalPrice + v.Value * 12;
                }
                if (v.Key == 'D')
                {
                    if (v.Value > 0)
                        this.TotalPrice = this.TotalPrice + v.Value * 0.15;
                }
            }
           
        }

        public decimal Total()
        {
            return (decimal)TotalPrice;
        }
    }
}
