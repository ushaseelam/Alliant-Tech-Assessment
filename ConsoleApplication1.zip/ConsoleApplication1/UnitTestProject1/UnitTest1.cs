﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApplication1;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        private readonly Terminal _terminal;

        public UnitTest1()
        {
            this._terminal = new Terminal();
        }
        [TestMethod]
        public void TerminalScan()
        {
            decimal expected =(decimal)32.40;
            this._terminal.Scan("ABCDABAA");
            Assert.AreEqual(this._terminal.Total(),expected );
        }

        [TestMethod]
        public void TerminalScan2()
        {
            decimal expected = (decimal)7.25;
            this._terminal.Scan("CCCCCCC");
            Assert.AreEqual(this._terminal.Total(), expected);
        }

        [TestMethod]
        public void TerminalScan3()
        {
            decimal expected = (decimal)15.40;
            this._terminal.Scan("ABCD");
            Assert.AreEqual(this._terminal.Total(), expected);
        }
    }
}
